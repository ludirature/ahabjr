package com.max2d.Newgame;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}

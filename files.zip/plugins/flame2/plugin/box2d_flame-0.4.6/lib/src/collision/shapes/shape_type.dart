part of box2d;

/// Types of shapes
enum ShapeType { CIRCLE, EDGE, POLYGON, CHAIN }

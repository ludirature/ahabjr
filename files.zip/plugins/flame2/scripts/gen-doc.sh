#!/bin/bash -e

dartdoc
